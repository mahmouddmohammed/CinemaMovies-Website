import sqlite3
import bcrypt
def connectDb(name='database.db'):
    return sqlite3.connect(name,check_same_thread=False)

connection = connectDb("store.db")
#---------------------------------
#users
def createUsersTable():
    cursor = connection.cursor()
    query = """
    CREATE TABLE IF NOT EXISTS users(
    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
    full_name TEXT NOT NULL,
    username TEXT NOT NULL UNIQUE,
    password TEXT NOT NULL
    )
    """
    cursor.execute(query)
    connection.commit()


# add user to db after register
def addUser(name,username,password):
    cursor = connection.cursor()
    query = """
    INSERT INTO users(full_name,username,password) VALUES (?,?,?)
    """
    cursor.execute(query,(name,username,password,))
    connection.commit()

def checkUsernameExists(username):
    cursor = connection.cursor()
    query = """
    SELECT id FROM users WHERE username = ?
    """
    cursor.execute(query,(username,))

    if cursor.fetchone():
        return True
    else:
        return False
    
def getUserId(username):
    cursor = connection.cursor()
    query = """
    SELECT id FROM users WHERE username = ?
    """
    cursor.execute(query,(username,))

    return cursor.fetchone()[0]
    
#when login , check if the username and password exactly matches
def loginUserDb(username,password):
    cursor = connection.cursor()
    query = """
    SELECT password FROM users WHERE username = ?
    """
    cursor.execute(query,(username,))
    stored_hashpassword = cursor.fetchone()
    if stored_hashpassword:
        if bcrypt.checkpw(password.encode(),stored_hashpassword[0].encode()): #tuple' object has no attribute 'encode' , password and hashed password must be both encoded
            return True
    return False



#-----------------------------------------
# Movie Uploader

def createUploadersTable():
    cursor = connection.cursor()
    query = """
    CREATE TABLE IF NOT EXISTS uploaders(
    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
    full_name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    password TEXT NOT NULL
    )
    """
    cursor.execute(query)
    connection.commit()

def addUploader(name,email,password):
    cursor = connection.cursor()
    query = """
    INSERT INTO uploaders(full_name,email,password) VALUES (?,?,?)
    """
    cursor.execute(query,(name,email,password,))
    connection.commit()


def checkEmailExists(email):
    cursor = connection.cursor()
    query = """
    SELECT id FROM uploaders WHERE email = ?
    """
    cursor.execute(query,(email,))

    if cursor.fetchone():
        return True
    else:
        return False
    
def getUploaderId(email):
    cursor = connection.cursor()
    query = """
    SELECT id FROM uploaders WHERE email = ?
    """
    cursor.execute(query,(email,))

    return cursor.fetchone()[0]


def loginUploaderDb(email,password):
    cursor = connection.cursor()
    query = """
    SELECT password FROM uploaders WHERE email = ?
    """
    cursor.execute(query,(email,))
    stored_hashpassword = cursor.fetchone()
    if stored_hashpassword:
        if bcrypt.checkpw(password.encode(),stored_hashpassword[0].encode()): #tuple' object has no attribute 'encode' , password and hashed password must be both encoded
            return True
    return False





#--------------------------
def createMoviesTable():
    cursor = connection.cursor()
    query = """
    CREATE TABLE IF NOT EXISTS movies(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    uploader_id INTEGER NOT NULL,
    name TEXT NOT NULL,
    price REAL NOT NULL,
    description TEXT NOT NULL,
    image_url TEXT NOT NULL,
    video_url TEXT NOT NULL,
    no_buyers REAL DEFAULT 0.0 
    )
    """
    #Real : Real Number
    cursor.execute(query)
    connection.commit()

def addMovie(uploader_id,movie_name,movie_price,movie_description,movie_image_path,movie_video_path):
    cursor = connection.cursor()
    query = """
    INSERT INTO movies(uploader_id,name,price,description,image_url,video_url) VALUES (?,?,?,?,?,?)
    """  
    cursor.execute(query,(uploader_id,movie_name,movie_price,movie_description,movie_image_path,movie_video_path,))
    connection.commit()

def getAllMovies(): #tlama get fa lazm t3ml return 3shan trg3 data
    cursor = connection.cursor()
    query = """SELECT * FROM movies"""
    cursor.execute(query)
    return cursor.fetchall()  # It will return List of Tuples aftet you loop by jinja you will access by index , I want to show it by practical

    #0 > movie_id , 1>uploader_id, 2>name, 3>price, 4>description, 5>image_url, 6>video_url , 7>nobuyers


def getMovie(movie_id):
    cursor = connection.cursor()
    query = """ 
    SELECT * FROM movies WHERE id = ?
    """
    cursor.execute(query,(movie_id,))
    return cursor.fetchone() # that will return a tuple you can access it through index


#def getAllMovies()  tlama get fa lazm t3ml return 3shan trg3 data
    

#def getMovie()  #Search by name or by id
"""
def createMovieUploaderTable():
    cursor = connection.cursor()
    query = 

    
    cursor.execute(query)
    connection.commit()


# add user to db after register
def addMovieUploader(name,email,password):
    cursor = connection.cursor()
    query = 

    
    cursor.execute(query)
    connection.commit()


#when login , check if the email and password exactly matches
def checkEmailExists(email):
    cursor = connection.cursor()
    query = 

    
    cursor.execute(query)
    connection.commit()


def accountMatches(email,password):








def createMoviesTable():


def addMovie():


def getAllMovies():


def getMovie():




def createRatingTable():

def rating_product():


def CreateCommentTable():

"""