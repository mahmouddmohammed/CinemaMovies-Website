from db import *
from validators import *
from security import *
from flask import Flask , request , redirect, render_template,flash, url_for, session 
import sqlite3
import hashlib
import bcrypt
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
import os



app = Flask(__name__)
app.secret_key = "Key!!!"
#user (guest)

@app.route("/login",methods=["GET","POST"])
def loginUser():
    if request.method == "GET":
        return render_template("signin.html")
    elif request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]

        if loginUserDb(username,password):
            session['logged_in'] = True
            session['is_user'] = True
            session['username'] = username
            return redirect("/home")
            #return render_template("task.html",username=username,password=password)
        else:
            flash("Wrong username of password","danger")
            return render_template("signin.html")
    


@app.route("/register",methods=["GET","POST"])
def registerUser():
    if request.method == "GET":
        return render_template("signup.html")
    elif request.method == "POST":
        full_name = request.form["name"] #mwgod fy html name attribute
        username = request.form["username"]
        password = request.form["password"]
        print (password)
        if checkUsernameExists(username):
            flash("There is an account by this user","danger")
            return render_template("register.html")
        if (not(check_password_length(password) and check_password_characters(password))):
            flash("Invalid Password, Password should contain digits , lowercase character , upercase characters ,special characters","danger")
            return render_template("signup.html")

        hashed_password = hashPassword(password)
        addUser(full_name,username,hashed_password)     
        return redirect("/login")




#Movie Uploader
@app.route("/login-uploader",methods=["GET","POST"])
def loginUploader():
    if request.method == "GET":
        return render_template("signin-uploader.html")
    elif request.method == "POST":
        email = request.form["email"]
        password = request.form["password"]

        if not checkEmail(email):
            flash("Invalid Email or Password","danger")
            return render_template("signin-uploader.html")


        if loginUploaderDb(email,password):
            session['logged_in'] = True
            session['is_uploader'] = True
            session['email'] = email
            return redirect("/home")
            #return render_template("task.html",username=username,password=password)
        else:
            flash("Wrong username of password","danger")
            return render_template("signin-uploader.html")

@app.route("/register-uploader",methods=["GET","POST"])
def registerUploader():
    if request.method=="GET":
        return render_template("signup-uploader.html")
    elif request.method == "POST":
        full_name = request.form["name"] #mwgod fy html name attribute
        email = request.form["email"]
        password = request.form["password"]

        if checkEmailExists(email):
            flash("There is an account by this user","danger")
            return render_template("signup-uploader.html")
        
        if not checkEmail(email):
            flash("Invalid Email or Password","danger")
            return render_template("signin-uploader.html")
        

        if (not(check_password_length(password) and check_password_characters(password))):
            flash("Invalid Password, Password should contain digits , lowercase character , upercase characters ,special characters","danger")
            return render_template("signup-uploader.html")

        hashed_password = hashPassword(password)
        addUploader(full_name,email,hashed_password)     
        return redirect("/login-uploader")


@app.route("/",methods = ["GET"])
def root_dir(): #index : home : root
    redirect("/home")


@app.route("/home",methods=["GET","POST"])
def home():
    if 'is_uploader' in session:
        if session['is_uploader']:
            return "For Uploader" #Render template
        else:
            return "NO"
    
    elif 'is_user' in session:
        if session['is_user']:
            return "For User"
        else:
            return "NO"
    
    else:
        return "NO"
    
@app.route("/upload-movie",methods=["GET","POST"])
def uploadMovie():
    if request.method == "GET":
        if 'is_user' in session:
            return "Forbidden, You dont have access to this page"
        
        if 'is_uploader' in session:
            if not session['is_uploader']:
                return "You dont have access to this page , Please log in"
            
        return render_template("upload-movie.html")
    

    elif request.method == "POST":
        return "2"
        

if __name__ == "__main__":
    createUsersTable()
    createUploadersTable()
    app.run(debug=True)