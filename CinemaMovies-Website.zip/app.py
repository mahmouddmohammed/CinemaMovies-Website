from db import *
from validators import *
from security import *
from flask import Flask , request , redirect, render_template,flash, url_for, session 
import sqlite3
import hashlib
import bcrypt
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
import os



app = Flask(__name__)
app.secret_key = "Key!!!"
#user (guest)

@app.route("/login",methods=["GET","POST"])
def loginUser():
    if request.method == "GET":
        return render_template("signin.html")
    elif request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]

        if loginUserDb(username,password):
            session['logged_in'] = True
            session['is_user'] = True
            session['is_uploader'] = False
            session['username'] = username
            return redirect("/home")
            #return render_template("task.html",username=username,password=password)
        else:
            flash("Wrong username of password","danger")
            return render_template("signin.html")
    


@app.route("/register",methods=["GET","POST"])
def registerUser():
    if request.method == "GET":
        return render_template("signup.html")
    elif request.method == "POST":
        full_name = request.form["name"] #mwgod fy html name attribute
        username = request.form["username"]
        password = request.form["password"]
        print (password)
        if checkUsernameExists(username):
            flash("There is an account by this user","danger")
            return render_template("register.html")
        if (not(check_password_length(password) and check_password_characters(password))):
            flash("Invalid Password, Password should contain digits , lowercase character , upercase characters ,special characters","danger")
            return render_template("signup.html")

        hashed_password = hashPassword(password)
        addUser(full_name,username,hashed_password)     
        return redirect("/login")




#Movie Uploader
@app.route("/login-uploader",methods=["GET","POST"])
def loginUploader():
    if request.method == "GET":
        return render_template("signin-uploader.html")
    elif request.method == "POST":
        email = request.form["email"]
        password = request.form["password"]

        if not checkEmail(email):
            flash("Invalid Email or Password","danger")
            return render_template("signin-uploader.html")


        if loginUploaderDb(email,password):
            session['logged_in'] = True
            session['is_uploader'] = True
            session['is_user'] = False
            session['email'] = email
            return redirect("/home")
            #return render_template("task.html",username=username,password=password)
        else:
            flash("Wrong username of password","danger")
            return render_template("signin-uploader.html")

@app.route("/register-uploader",methods=["GET","POST"])
def registerUploader():
    if request.method=="GET":
        return render_template("signup-uploader.html")
    elif request.method == "POST":
        full_name = request.form["name"] #mwgod fy html name attribute
        email = request.form["email"]
        password = request.form["password"]

        if checkEmailExists(email):
            flash("There is an account by this user","danger")
            return render_template("signup-uploader.html")
        
        if not checkEmail(email):
            flash("Invalid Email or Password","danger")
            return render_template("signin-uploader.html")
        

        if (not(check_password_length(password) and check_password_characters(password))):
            flash("Invalid Password, Password should contain digits , lowercase character , upercase characters ,special characters","danger")
            return render_template("signup-uploader.html")

        hashed_password = hashPassword(password)
        addUploader(full_name,email,hashed_password)     
        return redirect("/login-uploader")


@app.route("/",methods = ["GET"])
def root_dir(): #index : home : root
    redirect("/home")


@app.route("/home",methods=["GET","POST"])
def home():
    if 'is_uploader' in session:
        if session['is_uploader']:
            return "For Uploader" #Render template
        else:
            return "NO"
    
    elif 'is_user' in session:
        if session['is_user']:
            return "For User"
        else:
            return "NO"
    
    else:
        return "NO"
    
@app.route("/upload-movie",methods=["GET","POST"])
def uploadMovie():
    if request.method == "GET":
        if 'is_uploader' in session:
            if session['is_uploader'] == True:
                return render_template("upload-movie.html")  
        return "Forbidden,You dont have access to this page , Please log in"
            
    elif request.method == "POST":
        #LAZM FY HTML YKON FORM FEHA MULTIPART 3shan file ytb3t 3la kza request
        movie_name = request.form["movie_name"]
        movie_price = request.form["price"]
        movie_description = request.form["description"]
        movie_image = request.files["movie_image"]
        movie_video = request.files["movie_video"]

        #check if user didnt upload image or video or name is empty
        # NONE returns FALSE
        if not movie_image or movie_image.filename=='':
            flash("Image Is Required", "danger")
            return render_template("upload-movie.html")
        
        if not movie_video or movie_video.filename == '':
            flash("Video Is Required", "danger")
            return render_template("upload-movie.html")
        
        #Check the extension of image and video and the size

        if not (allowed_fileImage(movie_image.filename)) or not allowed_file_sizeImage(movie_image) :
            flash("Invalid File is Uploaded", "danger")
            return render_template("upload-gadget.html")
			
        
        if not (allowed_fileVideo(movie_video.filename)) or not allowed_file_sizeVideo(movie_video):
            flash("Invalid File is Uploaded", "danger")
            return render_template("upload-gadget.html")

        #movie_image and movie_video object has 1 attributes which is ".filename" and 1 method which is ".save()"

        #Save Movie Image
        movie_image_url = f"uploads_posters/{movie_image.filename}" #path
        movie_image.save(os.path.join("static",movie_image_url))

        #Save Movie Video
        movie_video_url = f"uploads_videos/{movie_video.filename}"
        movie_video.save(os.path.join("static",movie_video_url))

        uploader_id = getUploaderId(session['email'])

        addMovie(uploader_id,movie_name,movie_price,movie_description,movie_image_url,movie_video_url)
        return redirect(url_for('home'))





if __name__ == "__main__":
    createUsersTable()
    createUploadersTable()
    createMoviesTable()
    app.run(debug=True)