import bcrypt
from flask import session
def hashPassword(password):
    #add salt
    salt = bcrypt.gensalt()
    hashed_password = bcrypt.hashpw(password.encode(),salt) # you must pass the password encoded
    return hashed_password.decode()


def check_isUploader():
    if 'is_uploader' in session:
        if session['is_uploader'] == True:
            return True
    
    return False

def check_isUser():
    if 'is_user' in session:
        if session['is_user'] == True:
            return True
    
    return False






























































































































