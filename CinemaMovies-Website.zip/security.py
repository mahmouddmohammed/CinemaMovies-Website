import bcrypt
def hashPassword(password):
    #add salt
    salt = bcrypt.gensalt()
    hashed_password = bcrypt.hashpw(password.encode(),salt) # you must pass the password encoded
    return hashed_password.decode()